import streamlit as st
import random
import string

import balaman_bank_auth
import balaman_bank_storage
import balaman_bank_transactions
import balaman_bank_analysis
import balaman_bank_utils


# ==========================================
# PAGE CONFIGURATION
# ==========================================

st.set_page_config(
    page_title="Balaman Bank",
    page_icon="🏦",
    layout="wide",
    initial_sidebar_state="expanded"
)


# ==========================================
# CUSTOM STYLES & BRANDING
# ==========================================

st.markdown(
    """
    <style>
    /* Professional metric card styling */
    div[data-testid="metric-container"] {
        background-color: #ffffff;
        border: 1px solid #e0e6ed;
        padding: 15px 20px;
        border-radius: 8px;
        box-shadow: 0 2px 4px rgba(0,0,0,0.05);
        border-left: 5px solid #0052cc;
    }
    
    /* Enhance button appearance */
    .stButton>button {
        border-radius: 6px;
        font-weight: 600;
        transition: all 0.3s ease;
    }
    .stButton>button:hover {
        transform: scale(1.02);
    }
    </style>
    """,
    unsafe_allow_html=True
)


# ==========================================
# SESSION STATE
# ==========================================

if "logged_in" not in st.session_state:
    st.session_state.logged_in = False

if "account" not in st.session_state:
    st.session_state.account = None


# ==========================================
# LOGIN / REGISTRATION
# ==========================================

if not st.session_state.logged_in:

    # Center the login/registration forms using columns
    col1, col2, col3 = st.columns([1, 2, 1])

    with col2:
        st.title("🏦 balaman BANK")
        st.caption("Secure Digital Banking System • Client Portal")
        st.divider()

        login_tab, register_tab = st.tabs(
            [
                "🔐 Login",
                "📝 Register"
            ]
        )

        # ======================================
        # LOGIN
        # ======================================
        with login_tab:
            st.subheader("Welcome Back")
            
            with st.container(border=True):
                account_number = st.text_input(
                    "Account Number",
                    key="login_account"
                )

                pin = st.text_input(
                    "PIN",
                    type="password",
                    key="login_pin"
                )

                if st.button("Login Securely", type="primary", use_container_width=True):

                    account, message = (
                        balaman_bank_auth
                        .login_account(account_number, pin)
                    )

                    if account is not None:
                        st.session_state.logged_in = True
                        st.session_state.account = account
                        st.success(message)
                        st.rerun()
                    else:
                        st.error(message)

        # ======================================
        # REGISTRATION
        # ======================================
        with register_tab:
            st.subheader("Create Your Bank Account")
            
            with st.container(border=True):
                name = st.text_input(
                    "Full Name",
                    key="register_name"
                )

                account_number = st.text_input(
                    "Account Number",
                    key="register_account"
                )
                
                # Group PIN inputs side-by-side
                pin_col1, pin_col2 = st.columns(2)
                with pin_col1:
                    pin = st.text_input(
                        "Create 4-Digit PIN",
                        type="password",
                        key="register_pin"
                    )
                with pin_col2:
                    confirm_pin = st.text_input(
                        "Confirm PIN",
                        type="password",
                        key="register_confirm_pin"
                    )

                account_type = st.selectbox(
                    "Account Type",
                    [
                        "Savings Account",
                        "Student Account"
                    ]
                )

                starting_balance = st.number_input(
                    "Starting Balance (₱)",
                    min_value=0.0,
                    step=100.0,
                    format="%.2f"
                )

                if st.button("Create Account", type="primary", use_container_width=True):

                    account, message = (
                        balaman_bank_auth
                        .register_account(
                            name,
                            account_number,
                            pin,
                            confirm_pin,
                            account_type,
                            starting_balance
                        )
                    )

                    if account is not None:
                        st.success(message)
                        st.info("Your account has been created. Please use the Login tab to access your dashboard.")
                    else:
                        st.error(message)


# ==========================================
# LOGGED-IN BANKING APPLICATION
# ==========================================
else:

    account = st.session_state.account

    # ======================================
    # SIDEBAR
    # ======================================
    st.sidebar.title("🏦 balaman BANK")

    with st.sidebar.container(border=True):
        st.write(f"👤 **{account.account_name}**")
        st.caption(f"🛡️ {account.get_account_type()}")
        st.write(f"🔢 Account: `{account.account_number}`")

    st.sidebar.divider()

    menu = st.sidebar.radio(
        "MAIN MENU",
        [
            "📊 Dashboard",
            "💵 Deposit",
            "🏧 Withdraw",
            "💸 Money Transfer",
            "🧾 Bills Payment",
            "🎁 Buy e-Gift Card",
            "🔐 Change PIN",
            "📜 Transaction History",
            "📈 Transaction Analysis"
        ]
    )

    st.sidebar.divider()

    if st.sidebar.button("🚪 Logout", use_container_width=True):
        st.session_state.logged_in = False
        st.session_state.account = None
        st.rerun()

    # ======================================
    # DASHBOARD
    # ======================================
    if menu == "📊 Dashboard":

        st.header(f"Welcome back, {account.account_name} 👋")
        st.caption("Access your account overview and current status.")
        st.divider()

        st.subheader("💳 Account Overview")

        col1, col2, col3 = st.columns(3)

        with col1:
            st.metric(
                "Current Balance",
                balaman_bank_utils
                .format_currency(account.check_balance())
            )

        with col2:
            st.metric("Account Type", account.get_account_type())

        with col3:
            st.metric("Account Number", account.account_number)

        st.write("")
        st.info("💡 **Tip:** Use the sidebar menu to process transactions or view detailed analytics.")

    # ======================================
    # DEPOSIT
    # ======================================
    elif menu == "💵 Deposit":

        st.header("💵 Deposit Funds")
        st.caption("Securely add funds to your account.")
        st.divider()

        col1, col2 = st.columns([2, 1])

        with col1:
            with st.container(border=True):
                st.write(
                    f"**Current Balance:** "
                    f"{balaman_bank_utils.format_currency(account.check_balance())}"
                )

                amount = st.number_input(
                    "Deposit Amount (₱)",
                    min_value=0.0,
                    step=100.0,
                    format="%.2f"
                )

                if st.button("Confirm Deposit", type="primary", use_container_width=True):
                    if not balaman_bank_utils.is_valid_amount(amount):
                        st.error("⚠️ Invalid deposit amount.")
                    else:
                        success = account.deposit(amount)
                        if success:
                            balaman_bank_storage.update_account(account)
                            balaman_bank_transactions.record_transaction(
                                account, "Deposit", amount
                            )
                            st.success("✅ Deposit successful.")
                            
                            with col2:
                                st.metric(
                                    "New Balance",
                                    balaman_bank_utils
                                    .format_currency(account.check_balance())
                                )

    # ======================================
    # WITHDRAW
    # ======================================
    elif menu == "🏧 Withdraw":

        st.header("🏧 Withdraw Funds")
        st.caption("Securely withdraw funds from your account.")
        st.divider()

        col1, col2 = st.columns([2, 1])

        with col1:
            with st.container(border=True):
                st.write(
                    f"**Available Balance:** "
                    f"{balaman_bank_utils.format_currency(account.check_balance())}"
                )

                amount = st.number_input(
                    "Withdrawal Amount (₱)",
                    min_value=0.0,
                    step=100.0,
                    format="%.2f"
                )

                if st.button("Confirm Withdrawal", type="primary", use_container_width=True):
                    if not balaman_bank_utils.is_valid_amount(amount):
                        st.error("⚠️ Invalid withdrawal amount.")
                    elif amount > account.check_balance():
                        st.error("❌ Insufficient balance.")
                    else:
                        success = account.withdraw(amount)
                        if success:
                            balaman_bank_storage.update_account(account)
                            balaman_bank_transactions.record_transaction(
                                account, "Withdraw", amount
                            )
                            st.success("✅ Withdrawal successful.")
                            
                            with col2:
                                st.metric(
                                    "New Balance",
                                    balaman_bank_utils
                                    .format_currency(account.check_balance())
                                )
                                
    # ======================================
    # MONEY TRANSFER (NEW)
    # ======================================
    elif menu == "💸 Money Transfer":

        st.header("💸 Money Transfer")
        st.caption("Send funds to another balaman Bank account securely.")
        st.divider()

        col1, col2 = st.columns([2, 1])

        with col1:
            with st.container(border=True):
                st.write(f"**Available Balance:** {balaman_bank_utils.format_currency(account.check_balance())}")
                
                dest_account_num = st.text_input("Destination Account Number")
                
                amount = st.number_input(
                    "Transfer Amount (₱)",
                    min_value=0.0,
                    step=100.0,
                    format="%.2f"
                )

                if st.button("Confirm Transfer", type="primary", use_container_width=True):
                    if not balaman_bank_utils.is_valid_amount(amount):
                        st.error("⚠️ Invalid transfer amount.")
                    elif dest_account_num == account.account_number:
                        st.error("❌ You cannot transfer money to your own account.")
                    elif amount > account.check_balance():
                        st.error("❌ Insufficient balance.")
                    else:
                        # Fetch the destination account using existing storage logic
                        target_account = balaman_bank_storage.find_account(dest_account_num)
                        
                        if target_account is None:
                            st.error("❌ Destination account not found. Please check the account number.")
                        else:
                            # Perform the OOP actions
                            account.withdraw(amount)
                            target_account.deposit(amount)
                            
                            # Save state to storage
                            balaman_bank_storage.update_account(account)
                            balaman_bank_storage.update_account(target_account)
                            
                            # Record transactions for both parties
                            balaman_bank_transactions.record_transaction(account, f"Transfer Out to {dest_account_num}", amount)
                            balaman_bank_transactions.record_transaction(target_account, f"Transfer In from {account.account_number}", amount)
                            
                            st.success(f"✅ Successfully transferred {balaman_bank_utils.format_currency(amount)} to Account {dest_account_num}.")
                            
                            with col2:
                                st.metric(
                                    "New Balance",
                                    balaman_bank_utils.format_currency(account.check_balance())
                                )

    # ======================================
    # BILLS PAYMENT (NEW)
    # ======================================
    elif menu == "🧾 Bills Payment":

        st.header("🧾 Bills Payment")
        st.caption("Pay your utility bills directly from your account.")
        st.divider()

        col1, col2 = st.columns([2, 1])

        with col1:
            with st.container(border=True):
                st.write(f"**Available Balance:** {balaman_bank_utils.format_currency(account.check_balance())}")
                
                biller = st.selectbox(
                    "Select Biller", 
                    ["Davao Light (Electric)", "Davao Water District", "PLDT Home (Internet)", "Globe Telecom"]
                )
                
                ref_number = st.text_input("Account / Reference Number")
                
                amount = st.number_input(
                    "Payment Amount (₱)",
                    min_value=0.0,
                    step=100.0,
                    format="%.2f"
                )

                if st.button("Pay Bill", type="primary", use_container_width=True):
                    if not ref_number.strip():
                        st.error("⚠️ Please enter a valid reference number.")
                    elif not balaman_bank_utils.is_valid_amount(amount):
                        st.error("⚠️ Invalid payment amount.")
                    elif amount > account.check_balance():
                        st.error("❌ Insufficient balance.")
                    else:
                        success = account.withdraw(amount)
                        if success:
                            balaman_bank_storage.update_account(account)
                            
                            # Extract short biller name for cleaner transaction logging
                            short_biller = biller.split(' ')[0]
                            balaman_bank_transactions.record_transaction(account, f"Bills Payment - {short_biller}", amount)
                            
                            st.success(f"✅ Successfully paid {balaman_bank_utils.format_currency(amount)} to {biller}.")
                            
                            with col2:
                                st.metric(
                                    "New Balance",
                                    balaman_bank_utils.format_currency(account.check_balance())
                                )

    # ======================================
    # BUY E-GIFT CARD (NEW / UNIQUE)
    # ======================================
    elif menu == "🎁 Buy e-Gift Card":

        st.header("🎁 Buy e-Gift Card")
        st.caption("Purchase digital gift cards for premium services and gaming.")
        st.divider()

        col1, col2 = st.columns([2, 1])

        with col1:
            with st.container(border=True):
                st.write(f"**Available Balance:** {balaman_bank_utils.format_currency(account.check_balance())}")
                
                brand = st.selectbox(
                    "Select Brand", 
                    ["Steam Wallet", "Netflix", "Spotify Premium", "Roblox", "Valorant Points"]
                )
                
                amount = st.selectbox(
                    "Select Denomination (₱)", 
                    [250.0, 500.0, 1000.0, 2500.0]
                )

                if st.button("Purchase Gift Card", type="primary", use_container_width=True):
                    if amount > account.check_balance():
                        st.error("❌ Insufficient balance.")
                    else:
                        success = account.withdraw(amount)
                        if success:
                            balaman_bank_storage.update_account(account)
                            balaman_bank_transactions.record_transaction(account, f"e-Gift Card - {brand}", amount)
                            
                            # Generate a random 12-character alphanumeric voucher code
                            code = ''.join(random.choices(string.ascii_uppercase + string.digits, k=12))
                            formatted_code = f"{code[:4]}-{code[4:8]}-{code[8:]}"
                            
                            st.success("✅ Purchase successful!")
                            st.info(f"🎉 **Your {brand} Code:** `{formatted_code}`\n\n*Please save this code to redeem your balance.*")
                            
                            with col2:
                                st.metric(
                                    "New Balance",
                                    balaman_bank_utils.format_currency(account.check_balance())
                                )

    # ======================================
    # CHANGE PIN (NEW)
    # ======================================
    elif menu == "🔐 Change PIN":

        st.header("🔐 Change PIN")
        st.caption("Update your account security PIN.")
        st.divider()
        
        col1, col2 = st.columns([2, 1])

        with col1:
            with st.container(border=True):
                old_pin = st.text_input("Current PIN", type="password")
                new_pin = st.text_input("New 4-Digit PIN", type="password")
                confirm_new_pin = st.text_input("Confirm New PIN", type="password")
                
                if st.button("Update PIN", type="primary", use_container_width=True):
                    if not balaman_bank_auth.validate_pin(new_pin):
                        st.error("⚠️ New PIN must contain exactly 4 digits.")
                    elif new_pin != confirm_new_pin:
                        st.error("❌ New PINs do not match.")
                    elif old_pin == new_pin:
                        st.error("⚠️ New PIN must be different from the current PIN.")
                    else:
                        success = account.change_pin(old_pin, new_pin)
                        if success:
                            balaman_bank_storage.update_account(account)
                            
                            # Force update session state to ensure continuous login
                            st.session_state.account = account 
                            st.success("✅ PIN successfully updated. Please use your new PIN on your next login.")
                        else:
                            st.error("❌ Incorrect current PIN. Authorization failed.")

    # ======================================
    # TRANSACTION HISTORY
    # ======================================
    elif menu == "📜 Transaction History":

        st.header("📜 Transaction History")
        st.caption("Review your past account activity.")
        st.divider()

        transactions = (
            balaman_bank_transactions
            .get_transactions()
        )

        transactions = [
            transaction
            for transaction in transactions
            if transaction.get("account_number") == account.account_number
        ]

        if transactions:
            display_data = []
            for transaction in transactions:
                display_data.append({
                    "Date & Time": transaction.get("timestamp", "N/A"),
                    "Type": transaction.get("transaction", "N/A"),
                    "Amount": balaman_bank_utils.format_currency(
                        transaction.get("amount", 0)
                    ),
                    "Balance After": balaman_bank_utils.format_currency(
                        transaction.get("balance_after", 0)
                    )
                })

            st.dataframe(
                display_data,
                use_container_width=True,
                hide_index=True
            )
        else:
            st.info("🔍 No transaction history available.")

    # ======================================
    # TRANSACTION ANALYSIS
    # ======================================
    elif menu == "📈 Transaction Analysis":

        st.header("📈 Financial Analytics")
        st.caption("Insights and summaries based on your transaction history.")
        st.divider()

        result = (
            balaman_bank_analysis
            .analyze_transactions(account.account_number)
        )

        # ==================================
        # ANALYSIS 1: TRANSACTION SUMMARY
        # ==================================
        with st.container(border=True):
            st.subheader("1️⃣ Transaction Summary")
            col1, col2, col3 = st.columns(3)

            col1.metric("Total Transactions", result["total_transactions"])
            col2.metric("Deposits Count", result["deposits"])
            col3.metric("Withdrawals Count", result["withdrawals"])

        st.write("")

        # ==================================
        # ANALYSIS 2: MONEY FLOW
        # ==================================
        with st.container(border=True):
            st.subheader("2️⃣ Money Flow Analysis")
            col1, col2, col3 = st.columns(3)

            col1.metric(
                "Total Deposited",
                balaman_bank_utils.format_currency(result["total_deposited"])
            )
            col2.metric(
                "Total Withdrawn",
                balaman_bank_utils.format_currency(result["total_withdrawn"])
            )
            col3.metric(
                "Net Cash Flow",
                balaman_bank_utils.format_currency(result["net_cash_flow"])
            )

        st.write("")

        # ==================================
        # ANALYSIS 3: ACCOUNT ACTIVITY
        # ==================================
        with st.container(border=True):
            st.subheader("3️⃣ Account Activity Overview")
            col1, col2, col3 = st.columns(3)

            col1.metric(
                "Largest Transaction",
                balaman_bank_utils.format_currency(result["largest_transaction"])
            )
            col2.metric(
                "Average Transaction",
                balaman_bank_utils.format_currency(result["average_transaction"])
            )
            col3.metric("Latest Transaction", result["latest_transaction"])

            st.caption(f"⏱️ **Last activity recorded:** {result['latest_timestamp']}")
